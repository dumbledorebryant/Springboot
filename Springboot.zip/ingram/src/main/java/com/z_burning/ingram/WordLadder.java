package com.z_burning.ingram;

import java.util.*;

/*
 *Filename Javalab.java
 *@Author: Z.BurNIng Ingram
 *@Date: March 4th, 2018
 *
 */

class Judge
{
    String wordOne;
    String wordTwo;
    public boolean judge_length()
    {
        if( wordOne.length() != wordTwo.length() )
        {
            System.out.println("The two words must be the same length.");
            return false;
        }
        return true;
    }
    public boolean judge_equality()
    {
        if( wordOne.equals(wordTwo) )
        {
            System.out.println("The two words must be different.");
            return false;
        }
        return true;
    }
    public boolean judge_containing(Set<String> dict)
    {
        if( !dict.contains(wordOne) || !dict.contains(wordTwo))
        {
            System.out.println("The two words must be found in the dictionary.");
            return false;
        }
        return true;
    }
}


public class WordLadder
{
    public String solve(Judge wordPairs, Set<String> dict){

        String result="fuckU";
        String word1;
        String word2;
        Queue<Stack<String>> wordWay = new LinkedList<Stack<String>>();
        Set<String> appeared = new HashSet<String>();
        Stack<String> head_ladder = new Stack<String>();

        word1 = wordPairs.wordOne;
        word2 = wordPairs.wordTwo;

        int length = word1.length();

        head_ladder.push(word1);
        wordWay.offer(head_ladder);
        appeared.add(word1);

        boolean flag = true;
        while( !wordWay.isEmpty() && flag ){

            Stack<String> single_ladder = wordWay.poll();
            String word = single_ladder.peek();

            boolean flagA = true;
            for(int i = 0; i < length && flagA; i++)
            {
                char[] temp = word.toCharArray();
                boolean flagB = true;
                for(char j = 'a'; j <= 'z' && flagB; j++)
                {
                    temp[i] = j;
                    String neighbor = new String(temp);

                    if(dict.contains(neighbor) && !appeared.contains(neighbor))
                    {
                        if(neighbor.equals(word2))
                        {
                            result = "A ladder from "+ word2 + " back to " + word1 + ":\n";
                            result += neighbor;
                            while( !single_ladder.empty() )
                            {
                                result = result + (" " + single_ladder.pop());
                            }
                            result +="\n";

                            appeared.clear();
                            flag = false;
                            flagA = false;
                            flagB = false;
                        }
                        else {
                            Stack<String> newCopy = new Stack<String>();
                            for ( String step : single_ladder)
                            {
                                newCopy.push(step);
                            }
                            newCopy.push(neighbor);
                            wordWay.offer(newCopy);
                            appeared.add(neighbor);
                        }
                    }
                }
            }
        }
        if( flag )
        {
            result = "No word ladder found from " + word1 + " back to " + word2 + ".";
        }
        wordWay.clear();
        return result;
    }
}
