package com.z_burning.ingram;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;

@RestController
public class UserController {
    @RequestMapping(value = "/ladder", method = RequestMethod.GET)
    public String Ladder(
            @RequestParam(value = "word1", defaultValue = "") String word1,
            @RequestParam(value = "word2", defaultValue = "") String word2
    ) throws Exception {
        String result;
        Set<String> dict = new HashSet<>();
        Judge wordPairs = new Judge();
        wordPairs.wordOne = word1;
        wordPairs.wordTwo = word2;

            File findFile = new File("target/dictionary.txt");
            if (findFile.exists()) {
                BufferedReader fileReader = new BufferedReader(new FileReader(findFile));
                String dict_word = fileReader.readLine();
                while (dict_word != null) {
                    dict.add(dict_word);
                    dict_word = fileReader.readLine();
                }
            } else {
                result = "Unable to open that file.  Try again.";
                return result;
            }

        if( !wordPairs.judge_length() ) {}
        else if( !wordPairs.judge_equality() ) {}
        else if( !wordPairs.judge_containing(dict) ) {}

        WordLadder result_ladder = new WordLadder();
        return result_ladder.solve(wordPairs, dict);
    }
}